import {Component,OnInit,ViewChild} from '@angular/core';
import {User} from '../../models/User';
import {DataService} from '../../services/data.service';
@Component({

selector:'app-user',
templateUrl:'./user.component.html',
styleUrls:['./user.component.css']

})

export class UserComponent {
   
   
    users:User[];
    showUserForm:boolean=false;
    @ViewChild('userForm') form:any;
    user:User={
         
        firstname:'',
        lastname:'',
        email:''
    };
    

    constructor(private dataservice:DataService ){

        
    }



 onSubmit({value,valid}:{value:User,valid:boolean}){
   
    value.joined=new Date();
    value.hide=true;
    this.dataservice.addUser(value);
    this.form.reset();
 }
  

    ngOnInit(){
       this.users=this.dataservice.getUsers();
    }
}