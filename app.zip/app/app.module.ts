import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import {FormsModule} from '@angular/Forms';
import {HttpClientModule} from '@angular/common/http';

import { AppComponent } from './app.component';
import {UserComponent} from './components/user/user.components';
import { NavbarComponent } from './components/navbar/navbar.component';
import {DataService} from './services/data.service';
import {PostService} from './services/post.service';
import { PostsComponent } from './components/posts/posts.component';
@NgModule({
  declarations: [
    AppComponent,
    UserComponent,
    NavbarComponent,
    PostsComponent,
   
  ],
  imports: [
    BrowserModule,
    FormsModule,
    HttpClientModule

  ],
  providers: [DataService,PostService],
  bootstrap: [AppComponent]
})
export class AppModule { }
