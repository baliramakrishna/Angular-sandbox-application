import { Injectable } from '@angular/core';
import {User} from '../models/User';
@Injectable({
  providedIn: 'root'
})
export class DataService {
  
  users:User[];
  constructor() { 

     this.users=[{

           
      firstname:'raki',
      lastname:'krishna',
      joined:new Date(2018, 11, 24, 10, 33, 30, 0),
      email:"raki@gmail.com",
      hide:true
     },{

 
          firstname:'ravi',
          lastname:'siripurapu',
          joined:new Date(2018, 11, 24, 10, 33, 30, 0),
          email:"ravi123@gmail.com",
          hide:true
          
      },
      {

 
          firstname:'krishna',
          lastname:'kdridderry',
          joined:new Date(2018, 11, 24, 10, 33, 30, 0),
          email:"krishna@gmail.com",
          hide:true
      }


]
  }

  getUsers():User[]{
    return this.users;
  }
  addUser(user:User){
    this.users.unshift(user);
  }
}
