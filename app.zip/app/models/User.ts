
export interface User{

firstname:string,
lastname:string,
joined?:any
email?:string,
hide?:boolean



}